function index(req, res){
    req.getConnection((err, conn) => {
        conn.query('SELECT * FROM users', (err, users) =>{
        if(err){
            res.json(err);
        }
        console.log("--------",users)
        res.json('login/pers',{users});
    });
  });
}

    function create(req, res){
        res.render('login/register');
    }

    function store(req, res){
        const data = req.body;

        req.getConnection((err, conn) => {
            conn.query('INSERT INTO users SET ?', [data],(err, rows) =>{
            res.redirect('/pers');
        });
      });
     }


    function destroy(req, res){
        const data = req.body.id;

        req.getConnection((err, conn) => {
            conn.query('DELTE FROM users WHERE id = ?', [id],(err, rows) =>{
            if(err){
                res.json(err);
            }
            res.redirect('/login');
        });
      });
     }

    function edit(req, res){
        const data = req.params.id;

        req.getConnection((err, conn) => {
            conn.query('SELECT * FROM users WHERE id = ?', [id],(err, tasks) =>{
            if(err){
               res.json(err);
            }
            res.json('login/edit',{tasks});
        });
      });
     }

     function update(req, res){
        const id = req.params.id;
        const data = req.body;        

        req.getConnection((err, conn) => {
            conn.query('UPDATE users SET ? WHERE id = ?', [data,id],(err, rows) =>{
            if(err){
                res.json(err);
            }    
            res.redirect('login/');
        });
      });
     }
    
module.exports = {
    index: index,
    create: create,
    store: store,
    destroy: destroy,
    edit: edit,
    update,update,
  
  }