const express = require('express');
const LoginController = require('../controllers/LoginController');
const persController = require('../controllers/personalController');
const router = express.Router();

router.get('/login', LoginController.index);
router.get('/register', LoginController.register);
router.post('/register', LoginController.storeUser);
router.post('/login', LoginController.auth);
router.get('/logout', LoginController.logout);
router.get('/home', LoginController.home);
router.get('/pers', LoginController.pers);

router.get('/pers', persController.index);
router.get('/register', persController.create);
router.post('/register', persController.store);
router.post('/pers/delete', persController.destroy);
router.get('/pers/edit/:id', persController.edit);
router.post('/pers/edit/:id', persController.update)


module.exports = router;
