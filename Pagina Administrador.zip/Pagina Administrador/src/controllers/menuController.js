function menu(req, res) {
    //seleccion de la tabla de nuestra base de datos
    req.getConnection((err, conn) => {
        //le damos valor a la variable productos la cual sera nuestra tabla y nos servira para imprimir datos
        conn.query('SELECT * FROM productos', (err, productos) => {
            if(err){
                res.json(err);
            }
            //renderisacion de la pagina para la tabla
            res.render('menu/tablaMenu', { productos });
        });
    });
}

  
function alta(req, res) {
    res.render('menu/altaMenu');
}

//funcion para poder insertar nuestros datos ala base de datos
function store(req, res){
    const data = req.body;

    //conecta a la base eh inserta los datos dados por el usuario   
    req.getConnection((err, conn) => {
        conn.query('INSERT INTO productos SET ?', [data], (err, rows) =>{
            //una ves insertadoa nos dirigira a nuestra tabla 
            res.redirect('/menu');
        });
    });
}

//funcion para eliminar productos mediante su id en la base de datos
function destroy(req, res){
    const id = req.body.id;

    //coneccion de la base de datos
    req.getConnection((err, conn) =>{
        //query para poder elegir la tabla de la base de datos y su id y asi los elimine
        conn.query('DELETE FROM productos WHERE id = ?', [id], (err, rows) =>{
            //una ves eliminados nos redirigira a la tabla
            res.redirect('/menu')
        });
    });
}

//funcion para editar
function edit(req, res){
    const id = req.params.id;

    //coneccion de la base de datos
    req.getConnection((err, conn) => {
        //query para poder elegir la tabla de la base de datos y su id
        conn.query('SELECT * FROM productos WHERE ID = ?', [id], (err, productos) => {
             //si no se encuentran los datos anteriores marcara error
            if(err){
                res.json(err);
            }
            //si se encuentra nos renderesira la pagina de editar el cual nos mostrara el formulario con los datos del producto para editar
            res.render('menu/edit', { productos });
        });
    });
}

//Funcion para agregar los camios a la base de datos
function update(req, res){
    const id = req.params.id;
    const data = req.body;

    //cooneccion con la base de datos
    req.getConnection((err, conn) => {
        //query para selccionar los datos buscar el id y haci insertar los datos cambiados
        conn.query('UPDATE productos SET ? WHERE id = ?', [data, id], (err, rows) => {
            //una ves echo esto nos redireccionara a la tabla del menu 
            res.redirect('/menu')
        });
    });
}

  //exportacion de nuestras funciones 
  module.exports = {
    menu,
    alta,
    store,
    destroy,
    edit,
    update,
}