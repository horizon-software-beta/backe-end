const bcrypt = require('bcrypt');


function index(req, res) {
  if(req.session.loggedin != true){
    res.render('login/index');
  }else{
    res.redirect('/');
  }

}

function register(req, res) {
  if(req.session.loggedin != true){
    res.render('login/register');
  }else{
    res.redirect('/');
  }

}

function storeUser(req,res){
  const data=req.body;
  req.getConnection((err,conn) => {
    conn.query('SELECT * FROM users WHERE email = ?',[data.email], (err,userdata) => {
      if (userdata.length > 0){
        res.render('login/register', {error: 'El correo electronico ya existe'});
      } else {
          req.getConnection((err,conn) => {
            conn.query('INSERT INTO users SET ?',[data], (err,rows) => {
              req.session.loggedin = true;
              req.session.nombre = data.nombre;
              res.redirect('/'); 
            });
          });
      
      }
    });
  });
} 

function auth(req, res) {
  const data=req.body;
	//let email = req.body.email;
	//let password = req.body.password;

  req.getConnection((err,conn) => {
    conn.query('SELECT * FROM users WHERE email = ?',[data.email], (err,userdata) => {
      if (userdata.length > 0){
        userdata.forEach(element => {
          conn.query('SELECT * FROM users WHERE password = ?',[data.password], (err,userdata) => {
          if(userdata.length > 0){
            req.session.loggedin = true;
            req.session.nombre = element.nombre;
            
            res.redirect('/'); 
          }else{
            res.render('login/index', {error: 'Contraseña Incorrecta!'});
          }
        });
        });
      } else {
        res.render('login/index', {error: 'El correo electronico no existe'});
      }
      
    });
  });
}


function logout(req, res) {
  if (req.session.loggedin == true) {
    req.session.destroy();

  }
  res.redirect('/login');
}


function validarEmail(email){
  const expReg= /^[a-zA-Z0-9._-]+@(cetis155)\.(edu.mx)/
  const esValido= expReg.test(email);

  conn.query('SELECT * FROM users WHERE email = ?',[expReg], (err, userdata) => {
  if(userdata==true){
    res.redirect('/'); 
  }
  else{
    res.render('login/register', {error: 'El correo electronico es invalido'});
  }
});
}

module.exports = {
  index: index,
  register: register,
  auth: auth,
  logout: logout,
  storeUser: storeUser,
  validarEmail,

}
