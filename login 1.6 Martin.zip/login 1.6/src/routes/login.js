//Constantes para llamar a las carpetas con todo y sus funciones
const express = require('express');
const { requiresAuth } = require('express-openid-connect');
const LoginController = require('../controllers/LoginController');
const persController = require('../controllers/personalController');
const menuController = require('../controllers/menuController');

//funcion que nos ayuda a definir las rutas de nuestras paginas 
const router = express.Router();

//definimos la ruta que usaremos para la funcion index la cual nos redirigue hasia nuestro inicio de secion
router.get('/login', LoginController.index);
//definimos la ruta que usaremos para la funcion index la cual nos redirigue hasia nuestro formulario de registro
router.get('/register', LoginController.register);
//se utiliza la misma ruta register ya que la funcion store es la que nos agregara los datos a nuestra base
router.post('/register', LoginController.storeUser);
//se utiliza la misma ruta login ya que la funcion auth nos ayuda a iniciar sesion 
router.post('/login', LoginController.auth);
//definimos la ruta para poder cerrar sesion
router.get('/logout', LoginController.logout);
router.get('/personal', LoginController.personal);

//definimos la ruta que usaremos para la funcion index la cual nos redirigue hasia la tabla de datos
router.get('/pers', persController.index);
//definimos la ruta que usaremos para la funcion create la cual nos redirigue hasia el formulario 
//donde devemos insertar nuestros datos
router.get('/create', persController.create);
//se utiliza la misma ruta create ya que la funcion store es la que nos agregara los datos a nuestra base
router.post('/create', persController.store);
//definicion de la ruta que usaremos para eliminar usuarios
router.post('/pers/delete', persController.destroy);
//definicion de las rutas que usaremos para editar usuarios mas sus id
router.get('/pers/edita/:id', persController.edita);
router.post('/pers/edita/:id', persController.update);

//definimos la ruta que usaremos para la funcion menu la cual nos redirigue hasia la tabla de datos
router.get('/menu', menuController.menu);
//definimos la ruta que usaremos para la funcion alta la cual nos redirigue hasia el formulario 
//donde devemos insertar nuestros datos
router.get('/alta', menuController.alta);
//se utiliza la misma ruta create ya que la funcion store es la que nos agregara los datos a nuestra base
router.post('/alta', menuController.store);
//se utiliza la ruta destroy para que elimine el usuario de la base de datos 
router.post('/menu/delete', menuController.destroy);
//definicion de las rutas que usaremos para editar productos mas sus id
router.get('/menu/edit/:id', menuController.edit);
router.post('/menu/edit/:id', menuController.update);

//exportacion de las rutas
module.exports = router;
