//definicion de nuestra funcion y variable para ecriptar contraseña
const bcrypt = require('bcrypt');


function index(req, res) {
  console.log("entre");
    if (req.oidc.isAuthenticated()) {  
      console.log("autenticado");
    res.redirect('/register');
  } else {
    console.log("NO autenticado");
    res.render('/personal');
  }
}

//funcion para mostrarnos el formulario
function register(req, res) {
  if (req.session.loggedin) {
    res.redirect('/');
  } else {
    res.render('login/register');
  }
  
}

//funcion para poder insertar nuestros datos ala base de datos
function storeUser(req,res){
  const data=req.body;
  //conecta a la base eh inserta los datos dados por el usuario  
  req.getConnection((err,conn) => {
    //hace una comparacion con los emails para comprovar si no ay uno identico al que nos dio el usuario
    conn.query('SELECT * FROM users WHERE email= ?',[data.email], (err,userData) => {
      //si se euncuentra unos similar nos redirige a la pagina de alta personal y nos muestra un error
      if (userData.length>0){
        //hace la redireccion y definimos lo que dira el error
        res.render('login/register', {error: 'El correo electronico ya esta en uso'});
        //si  no se encuentra ninguno procedemos a encriptar la contraseña
      } else {
        //pedimos la contraseña y la encriptamos con un metodo hass
        bcrypt.hash(data.password, 12).then(hash => {
          console.log(hash);
          //una ves encriptada se imprimira la version encriptada
          data.password=hash;
          //console.log(data);
          //una ves completado todo se insertan los datos a la base con este query
          req.getConnection((err,conn) => {
              conn.query('INSERT INTO users SET ?',[data], (err,rows) => {
                //nos redirecciona a la pagina raiz
                res.redirect('/'); 
              });
          });
      
        });
      }
    });
  });
} 


//funcion parapoder iniciar sesion
function auth(req, res) {
  const data = req.body;
	//let email = req.body.email;
	//let password = req.body.password;

  //conecta con la base de datos
  req.getConnection((err, conn) => {
    //query para que aga la comparativa del email y ver si se encuentra uno simiar en la base de datos
    conn.query('SELECT * FROM users WHERE email = ?', [data.email], (err, userData) => {
      //si si se encuentra uno similar se ara esto
      if(userData.length > 0) {
        //se compararan las contraseñas 
        userData.forEach(element => {
          //se hace comparacion de contraseñas encriptadas
          bcrypt.compare(data.password,element.password, (err,isMatch) => {
            //si las contraseñas no coinciden se ejecutara lo siguinte
            if(!isMatch){
              console.log("out",userData);
              //si no son iguales saltara un error diciendo que la contraseña no coincide
              res.render('login/index', {error: 'Error password or email do not exist!'});
            } else {
              //si todo es similar podras ingresar a la pagina rai con una sesion iniciada
              console.log("wellcome");
              req.session.loggedin = true;
              req.session.name = element.name;
              res.redirect('/');
            }
          });   
        });     
      } else {
        res.render('login/index', {error: 'Error password or email do not exist!'});
      }    
    });
  });
}

//fucion para poder cerrar sesion
function logout(req, res) {
  //si se encuentra que si hay una sesion iniciada se destruira
  if (req.session.loggedin == true) {
    req.session.destroy();
  }
  //despues se mandara al incio de sesion con la sesion ya cerrada
  res.redirect('/login');
}

function personal(req, res) {
  res.render('pages/pers');
}

//exportacion de nuestras funciones 
module.exports = {
  index: index,
  register: register,
  auth: auth,
  logout: logout,
  storeUser: storeUser,
  personal: personal,

}

